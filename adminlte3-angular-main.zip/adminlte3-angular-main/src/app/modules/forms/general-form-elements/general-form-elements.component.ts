import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-general-form-elements',
  templateUrl: './general-form-elements.component.html',
  styleUrls: ['./general-form-elements.component.css']
})
export class GeneralFormElementsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
