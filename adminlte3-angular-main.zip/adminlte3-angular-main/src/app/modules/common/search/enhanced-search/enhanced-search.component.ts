import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enhanced-search',
  templateUrl: './enhanced-search.component.html',
  styleUrls: ['./enhanced-search.component.css']
})
export class EnhancedSearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
