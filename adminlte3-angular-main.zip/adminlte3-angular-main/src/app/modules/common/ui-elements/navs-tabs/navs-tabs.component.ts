import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navs-tabs',
  templateUrl: './navs-tabs.component.html',
  styleUrls: ['./navs-tabs.component.css']
})
export class NavsTabsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
