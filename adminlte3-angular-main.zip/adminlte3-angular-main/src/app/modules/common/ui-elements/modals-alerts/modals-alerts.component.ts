import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modals-alerts',
  templateUrl: './modals-alerts.component.html',
  styleUrls: ['./modals-alerts.component.css']
})
export class ModalsAlertsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
