import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-v1',
  templateUrl: './register-v1.component.html',
  styleUrls: ['./register-v1.component.css']
})
export class RegisterV1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
