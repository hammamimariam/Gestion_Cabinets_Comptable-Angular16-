import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-page-v1',
  templateUrl: './error-page-v1.component.html',
  styleUrls: ['./error-page-v1.component.css']
})
export class ErrorPageV1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
