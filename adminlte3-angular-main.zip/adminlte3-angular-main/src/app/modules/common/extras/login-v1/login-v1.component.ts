import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-v1',
  templateUrl: './login-v1.component.html',
  styleUrls: ['./login-v1.component.css']
})
export class LoginV1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
