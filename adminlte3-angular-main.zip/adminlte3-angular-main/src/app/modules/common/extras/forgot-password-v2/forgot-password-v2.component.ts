import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgot-password-v2',
  templateUrl: './forgot-password-v2.component.html',
  styleUrls: ['./forgot-password-v2.component.css']
})
export class ForgotPasswordV2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
