import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-v2',
  templateUrl: './login-v2.component.html',
  styleUrls: ['./login-v2.component.css']
})
export class LoginV2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
