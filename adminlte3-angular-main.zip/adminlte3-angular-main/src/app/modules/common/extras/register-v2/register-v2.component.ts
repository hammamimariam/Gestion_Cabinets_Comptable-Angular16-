import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-v2',
  templateUrl: './register-v2.component.html',
  styleUrls: ['./register-v2.component.css']
})
export class RegisterV2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
