import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-page-v2',
  templateUrl: './error-page-v2.component.html',
  styleUrls: ['./error-page-v2.component.css']
})
export class ErrorPageV2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
