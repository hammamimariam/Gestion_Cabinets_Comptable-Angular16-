import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starter-page',
  templateUrl: './starter-page.component.html',
  styleUrls: ['./starter-page.component.css']
})
export class StarterPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
