import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-legacy-user-menu',
  templateUrl: './legacy-user-menu.component.html',
  styleUrls: ['./legacy-user-menu.component.css']
})
export class LegacyUserMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
