import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recover-password-v2',
  templateUrl: './recover-password-v2.component.html',
  styleUrls: ['./recover-password-v2.component.css']
})
export class RecoverPasswordV2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
