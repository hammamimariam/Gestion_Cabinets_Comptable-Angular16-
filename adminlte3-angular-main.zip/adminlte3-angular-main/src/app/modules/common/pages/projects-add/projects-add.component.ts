import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-projects-add',
  templateUrl: './projects-add.component.html',
  styleUrls: ['./projects-add.component.css']
})
export class ProjectsAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
