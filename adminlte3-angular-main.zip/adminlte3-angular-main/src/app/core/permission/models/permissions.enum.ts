export enum Permission {
  None = 'None',
  View = 'View',
  Admin = 'Admin',
}
