export enum Features {
  Spa_Inventory = 'Spa Inventory',
}
